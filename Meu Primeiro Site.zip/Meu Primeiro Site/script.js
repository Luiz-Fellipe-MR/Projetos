        // ========================================
// INTERAÇÕES DOS BOTÕES
// ========================================

function jogar(jogo) {

    if (jogo === "velha") {

        alert("🎮 O Jogo da Velha será iniciado!");

    }

    else if (jogo === "jokenpo") {

        alert("✊ ✋ ✌️ Vamos jogar Jokenpô!");

    }

    else if (jogo === "numero") {

        alert("🔎 Pense em um número e vamos tentar descobrir!");
    }

}


// ========================================
// EFEITO NO MENU
// ========================================

const links = document.querySelectorAll("nav a");

links.forEach(function(link) {

    link.addEventListener("click", function() {

        console.log("Navegando pelo site...");

    });

});