// =================================
// PLACAR
// =================================

let pontosJogador = 0;
let pontosComputador = 0;
let quantidadeEmpates = 0;


// =================================
// FUNÇÃO PRINCIPAL DO JOGO
// =================================

function jogar(escolhaJogador) {

    // Opções que o computador pode escolher
    const opcoes = ["pedra", "papel", "tesoura"];


    // Computador escolhe uma opção aleatória
    const numeroAleatorio = Math.floor(Math.random() * 3);

    const escolhaComputador = opcoes[numeroAleatorio];


    // =================================
    // MOSTRAR AS ESCOLHAS
    // =================================

    document.getElementById("escolhaJogador").textContent =
        "Você: " + colocarEmoji(escolhaJogador);

    document.getElementById("escolhaComputador").textContent =
        "Computador: " + colocarEmoji(escolhaComputador);


    // =================================
    // VERIFICAR O RESULTADO
    // =================================

    if (escolhaJogador === escolhaComputador) {

        document.getElementById("mensagem").textContent =
            "🤝 Empate!";

        quantidadeEmpates++;
    }

    else if (
        (escolhaJogador === "pedra" && escolhaComputador === "tesoura") ||
        (escolhaJogador === "papel" && escolhaComputador === "pedra") ||
        (escolhaJogador === "tesoura" && escolhaComputador === "papel")
    ) {

        document.getElementById("mensagem").textContent =
            "🎉 Você venceu!";

        pontosJogador++;
    }

    else {

        document.getElementById("mensagem").textContent =
            "🤖 Computador venceu!";

        pontosComputador++;
    }


    // =================================
    // ATUALIZAR PLACAR
    // =================================

    document.getElementById("pontosJogador").textContent =
        pontosJogador;

    document.getElementById("pontosComputador").textContent =
        pontosComputador;

    document.getElementById("empates").textContent =
        quantidadeEmpates;
}


// =================================
// COLOCAR EMOJI NAS ESCOLHAS
// =================================

function colocarEmoji(escolha) {

    if (escolha === "pedra") {
        return "✊ Pedra";
    }

    else if (escolha === "papel") {
        return "✋ Papel";
    }

    else {
        return "✌️ Tesoura";
    }
}


// =================================
// ZERAR O PLACAR
// =================================

function reiniciarJogo() {

    pontosJogador = 0;
    pontosComputador = 0;
    quantidadeEmpates = 0;


    document.getElementById("pontosJogador").textContent = "0";

    document.getElementById("pontosComputador").textContent = "0";

    document.getElementById("empates").textContent = "0";


    document.getElementById("escolhaJogador").textContent =
        "Você: -";

    document.getElementById("escolhaComputador").textContent =
        "Computador: -";

    document.getElementById("mensagem").textContent =
        "Escolha uma opção para começar!";
}