let numeroSecreto = Math.floor(Math.random() * 100) + 1;

let tentativas = 0;

const palpite = document.getElementById("palpite");
const botaoChutar = document.getElementById("botaoChutar");
const mensagem = document.getElementById("mensagem");
const textoTentativas = document.getElementById("tentativas");
const botaoReiniciar = document.getElementById("botaoReiniciar");


botaoChutar.addEventListener("click", function () {

    const numeroDigitado = Number(palpite.value);


    if (numeroDigitado < 1 || numeroDigitado > 100) {

        mensagem.textContent =
            "Digite um número entre 1 e 100!";

        return;
    }


    tentativas++;

    textoTentativas.textContent =
        "Tentativas: " + tentativas;


    if (numeroDigitado === numeroSecreto) {

        mensagem.textContent =
            "🎉 Parabéns! Você acertou o número " +
            numeroSecreto +
            "!";

        botaoChutar.disabled = true;

        palpite.disabled = true;

        botaoReiniciar.style.display = "block";
    }

    else if (numeroDigitado < numeroSecreto) {

        mensagem.textContent =
            "📈 O número secreto é MAIOR!";
    }

    else {

        mensagem.textContent =
            "📉 O número secreto é MENOR!";
    }


    palpite.value = "";

    palpite.focus();

});


botaoReiniciar.addEventListener("click", function () {

    numeroSecreto =
        Math.floor(Math.random() * 100) + 1;

    tentativas = 0;

    textoTentativas.textContent =
        "Tentativas: 0";

    mensagem.textContent =
        "Escolha um número entre 1 e 100.";

    palpite.value = "";

    palpite.disabled = false;

    botaoChutar.disabled = false;

    botaoReiniciar.style.display = "none";

    palpite.focus();

});