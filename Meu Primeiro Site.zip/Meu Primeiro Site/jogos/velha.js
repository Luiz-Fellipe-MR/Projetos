// =================================
// VARIÁVEIS DO JOGO
// =================================

let jogoAtivo = true;

let esperandoComputador = false;

let tabuleiro = [
    "", "", "",
    "", "", "",
    "", "", ""
];


// =================================
// PLACAR
// =================================

let pontosJogador = 0;
let pontosComputador = 0;
let quantidadeEmpates = 0;


// =================================
// ELEMENTOS DO HTML
// =================================

const casas = document.querySelectorAll(".casa");

const vezJogador = document.getElementById("vezJogador");

const mensagem = document.getElementById("mensagem");

const botaoNovaRodada = document.getElementById("novaRodada");

const botaoZerarPlacar = document.getElementById("zerarPlacar");


// =================================
// POSSIBILIDADES DE VITÓRIA
// =================================

const combinacoesVitoria = [

    // Linhas
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],

    // Colunas
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],

    // Diagonais
    [0, 4, 8],
    [2, 4, 6]

];


// =================================
// JOGADOR CLICA
// =================================

casas.forEach(function (casa) {

    casa.addEventListener("click", function () {

        const posicao = Number(casa.getAttribute("data-posicao"));


        // Impede jogar em casa ocupada,
        // depois do fim ou durante a jogada do computador

        if (
            tabuleiro[posicao] !== "" ||
            jogoAtivo === false ||
            esperandoComputador === true
        ) {
            return;
        }


        // Jogador sempre é X

        tabuleiro[posicao] = "X";

        casa.textContent = "X";

        casa.classList.add("x");


        // Verifica se o jogador venceu

        if (verificarResultado("X")) {
            return;
        }


        // Se não venceu, é a vez do computador

        esperandoComputador = true;

        vezJogador.textContent = "Vez do computador...";

        mensagem.textContent = "🤖 Computador pensando...";


        // Pequeno tempo para parecer que o computador pensou

        setTimeout(function () {

            jogadaComputador();

        }, 500);

    });

});


// =================================
// JOGADA DO COMPUTADOR
// =================================

function jogadaComputador() {

    if (jogoAtivo === false) {
        return;
    }


    // Primeiro tenta ganhar

    let posicao = encontrarMelhorJogada("O");


    // Se não puder ganhar,
    // tenta impedir o jogador de ganhar

    if (posicao === -1) {

        posicao = encontrarMelhorJogada("X");

    }


    // Se o centro estiver livre,
    // computador escolhe o centro

    if (posicao === -1 && tabuleiro[4] === "") {

        posicao = 4;

    }


    // Se ainda não escolheu,
    // escolhe uma casa vazia aleatória

    if (posicao === -1) {

        const casasLivres = [];


        for (let i = 0; i < tabuleiro.length; i++) {

            if (tabuleiro[i] === "") {

                casasLivres.push(i);

            }

        }


        if (casasLivres.length > 0) {

            const numeroAleatorio =
                Math.floor(Math.random() * casasLivres.length);

            posicao = casasLivres[numeroAleatorio];

        }

    }


    // Faz a jogada

    if (posicao !== -1) {

        tabuleiro[posicao] = "O";

        casas[posicao].textContent = "O";

        casas[posicao].classList.add("o");

    }


    // Verifica se computador venceu

    if (verificarResultado("O")) {
        return;
    }


    // Volta para o jogador

    esperandoComputador = false;

    vezJogador.textContent = "Sua vez: X";

    mensagem.textContent = "Escolha uma casa!";

}


// =================================
// COMPUTADOR PROCURA UMA JOGADA
// =================================

function encontrarMelhorJogada(simbolo) {

    for (let i = 0; i < combinacoesVitoria.length; i++) {

        const combinacao = combinacoesVitoria[i];

        const a = combinacao[0];
        const b = combinacao[1];
        const c = combinacao[2];


        const valores = [
            tabuleiro[a],
            tabuleiro[b],
            tabuleiro[c]
        ];


        let quantidadeSimbolo = 0;
        let quantidadeVazio = 0;
        let posicaoVazia = -1;


        for (let j = 0; j < valores.length; j++) {

            if (valores[j] === simbolo) {

                quantidadeSimbolo++;

            }

            else if (valores[j] === "") {

                quantidadeVazio++;

                posicaoVazia = combinacao[j];

            }

        }


        // Se existem dois símbolos iguais
        // e uma casa vazia, joga nela

        if (
            quantidadeSimbolo === 2 &&
            quantidadeVazio === 1
        ) {

            return posicaoVazia;

        }

    }


    return -1;

}


// =================================
// VERIFICAR RESULTADO
// =================================

function verificarResultado(simbolo) {

    // Verifica vitória

    for (let i = 0; i < combinacoesVitoria.length; i++) {

        const combinacao = combinacoesVitoria[i];

        const a = combinacao[0];
        const b = combinacao[1];
        const c = combinacao[2];


        if (
            tabuleiro[a] === simbolo &&
            tabuleiro[b] === simbolo &&
            tabuleiro[c] === simbolo
        ) {

            jogoAtivo = false;

            esperandoComputador = false;


            if (simbolo === "X") {

                mensagem.textContent =
                    "🎉 Você venceu!";

                pontosJogador++;

                document.getElementById("pontosX").textContent =
                    pontosJogador;

            }

            else {

                mensagem.textContent =
                    "🤖 O computador venceu!";

                pontosComputador++;

                document.getElementById("pontosO").textContent =
                    pontosComputador;

            }


            vezJogador.textContent =
                "Fim da rodada!";

            return true;

        }

    }


    // =================================
    // VERIFICAR EMPATE
    // =================================

    if (!tabuleiro.includes("")) {

        jogoAtivo = false;

        esperandoComputador = false;

        quantidadeEmpates++;


        document.getElementById("empates").textContent =
            quantidadeEmpates;


        mensagem.textContent =
            "🤝 Deu velha! Empate!";

        vezJogador.textContent =
            "Fim da rodada!";

        return true;

    }


    return false;

}


// =================================
// NOVA RODADA
// =================================

botaoNovaRodada.addEventListener("click", function () {

    novaRodada();

});


function novaRodada() {

    jogoAtivo = true;

    esperandoComputador = false;


    tabuleiro = [
        "", "", "",
        "", "", "",
        "", "", ""
    ];


    casas.forEach(function (casa) {

        casa.textContent = "";

        casa.classList.remove("x");

        casa.classList.remove("o");

    });


    vezJogador.textContent =
        "Sua vez: X";

    mensagem.textContent =
        "Clique em uma casa para começar!";

}


// =================================
// ZERAR PLACAR
// =================================

botaoZerarPlacar.addEventListener("click", function () {

    pontosJogador = 0;

    pontosComputador = 0;

    quantidadeEmpates = 0;


    document.getElementById("pontosX").textContent = "0";

    document.getElementById("pontosO").textContent = "0";

    document.getElementById("empates").textContent = "0";


    novaRodada();

});